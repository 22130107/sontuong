var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__12ph~a8._.js")
R.c("server/chunks/node_modules_next_0fdpe18._.js")
R.c("server/chunks/node_modules_next_dist_0k~eexk._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_0o-41u5.js")
R.m(33102)
module.exports=R.m(33102).exports
